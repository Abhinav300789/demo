package com.myapp.shortest;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.PriorityQueue;

import org.springframework.stereotype.Component;
@Component
public class ShortestDistanceController {
	public static void Compute(Node source) {
		source.mindistance = 0;
		PriorityQueue<Node> q = new PriorityQueue<>();
		q.add(source);
		while (q.size() != 0) {
			Node node = q.poll();
			for (Edge e : node.adj) {
				Node node1 = e.target;
				double weight = e.weight;
				double distance = node.mindistance + weight;
				if (distance < node1.mindistance) {
					q.remove(node1);
					node1.mindistance = distance;
					node1.prev = node;
					q.add(node1);
				}
			}
		}
	}

	public static List<Node> getShortestPath(Node node) {
		List<Node> path = new ArrayList<>();
		for (Node node1 = node; node1 != null; node1 = node1.prev) {
			path.add(node1);
		}
		Collections.reverse(path);
		return path;
	}
}
