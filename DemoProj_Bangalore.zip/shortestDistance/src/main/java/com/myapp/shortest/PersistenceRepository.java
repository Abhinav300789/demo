package com.myapp.shortest;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface PersistenceRepository extends JpaRepository<Edge, String> {

}
