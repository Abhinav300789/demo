package com.myapp.shortest;

public class Node {
public String name;
public Edge []adj;
public double mindistance=Double.POSITIVE_INFINITY;
public Node prev;
public Node(String name) {
	this.name=name;
}
public String toString() {
	return name;
}
public int compareTo(Node node) {
	return Double.compare(mindistance, node.mindistance);
}
}
