package com.myapp.shortest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
@Repository
public class PersistenceImpl implements Persistence {
 @Autowired
 PersistenceRepository perRepo;
  public void persistNode(Edge e) {
	  perRepo.save(e);
  }
  public List<Edge> getShortestNode() {
		return (List<Edge>) perRepo.findAll();
	}
}
