package com.myapp.shortest;

public interface Persistence {
	 public void persistNode(Edge e);
}
