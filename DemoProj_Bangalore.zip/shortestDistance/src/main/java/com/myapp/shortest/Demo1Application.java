package com.myapp.shortest;

import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo1Application {

	@SuppressWarnings("static-access")
	public static void main(String[] args) {
		ShortestDistanceController con=new ShortestDistanceController();
		con.Compute(new Node("A"));
		List<Node> path = con.getShortestPath(new Node("Z"));
        System.out.println("Path: " + path);
		SpringApplication.run(Demo1Application.class, args);
	}

}

