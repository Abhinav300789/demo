package com.myapp.shortest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;


@org.springframework.web.bind.annotation.RestController
public class RestController {
@Autowired
PersistenceImpl pImpl;
@ResponseBody
@PostMapping("/short/{edgeName}")
public ResponseEntity<List<Edge>> persistNode(@PathVariable("edgeName") String edgeName) {
	pImpl.persistNode(new Edge(new Node(edgeName), 10) );
	return new ResponseEntity<List<Edge>>(HttpStatus.OK);
}
@GetMapping("/short")
public ResponseEntity<List<Edge>> getAllAddress() {
	System.out.println("======================================");
	List<Edge> list = ((PersistenceImpl) pImpl).getShortestNode();
	return new ResponseEntity<List<Edge>>(list, HttpStatus.OK);
}
}
